﻿#include "Include/__INIT__.h"

void USART_Init(void){
	DDRD |= (1<<PORTD3); // TX 핀 출력
	DDRD &= ~(1<<PORTD2); // RX 핀 입력
	UCSR1A = 0x00;
	UCSR1B = (1<< RXEN1) | (1<<TXEN1);
	UCSR1C |= (1<<UCSZ11) | (1<<UCSZ10); // 비동기, 8비트, Non Parity, 1 Stop Bit
	UBRR1H = 0x00;
	UBRR1L = 0x07;
}

void USART_TX(unsigned char data){ // 송신
	while(!(UCSR1A & 0x20)); // 송신 버퍼가 빌때까지 대기
	UDR1 = data;
}

char USART_RX(void){ // 수신
	while(!(UCSR1A & 0x80)); // 수신완료 될 때까지 대기
	return UDR1;
}

void USART_SEND(char* str){ // 문자열 송신
	while(*str){ // NULL 일때까지 반복
		USART_TX(*str++); //*str 후에 str++ 시행
	}
}

void USART_RECEIVE(char* buff, int size){ // 문자열 수신
	char c;
	int count = 0;
	
	while(1){
		c = USART_RX(); //한글자씩 수신
		
		if(c == '\n' || c == '\r'){ //마지막 문자인 경우
			buff[count] = '\0'; //문자열 버퍼 끝에 '\n' 추가
			break;
		}
		else if(count < size - 1){ // name 일땐 9, password 일땐 4 등등
			 buff[count] = c;
			 count++;
		}
		// 버퍼 초과 방지 (자동 종료)
		else {
			buff[count] = '\0';
			USART_SEND("\r\n[Warning] Input overflow.\r\n");
			break;
		}
	}
}

// USART 버퍼 비우기 함수
void USART_Flush(void) {
	unsigned char dummy;
	while (UCSR1A & (1 << RXC1)) dummy = UDR1;
}