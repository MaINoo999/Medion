package com.example.bluetooth_test;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    /* BluetoothAdapter
    * - 스마트폰의 블루투스 기능을 관리하는 객체
    * - 장치 검색, 페어링된 기기 목록 확인 등 담당 */
    private BluetoothAdapter btAdapter;

    /* BluetoothSocket
    * - 블루투스 시리얼 장치(HC-06)와의 데이터 통신 통로
    * - connect( )로 연결, getInputStream( )으로 데이터 수신 */
    private BluetoothSocket btSocket;

    /* InputStream
    * - HC-06 → Android 방향으로 데이터를 받을 입력 스트림
    * - AVR에서 USART_SEND( )로 전송한 문자열이 여기로 들어옴 */
    private InputStream inputStream;

    /* Textview : 수시한 온도 값을 화면에 표시
    * Button: Bluetooth 연결을 시작하는 트리거 */
    private TextView textView;
    private Button button;

    /* MAC 주소
    * - 블루투스 모듈을 식별하는 고유 번호
    * - HC-06 모듈에 붙어 있는 12자리 주소 그대로 사용 */
    private final String deviceAddress = "00:19:01:38:14:F7";

    /* UUID (Serial Port Profile)
    * - 블루투스에서 UART 통신을 흉내내는 RFCOMM 서비스의 공식 UUID
    * - 모든 HC-16은 이 UUID로 시리얼 연결 가능*/
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    /* messageBuffer
     * - HC-06에서 문자가 한 글자씩 들어오므로
     *   '\n'이 들어올 때까지 문자열을 임시로 쌓아두는 역할 */
    private String messageBuffer = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btAdapter = BluetoothAdapter.getDefaultAdapter();
        textView = findViewById(R.id.textview);
        button = findViewById(R.id.button);

        // 버튼 누르면 블루투스 연결 시도
        button.setOnClickListener(v -> connectBluetooth());
    }

    private void connectBluetooth() {
        /* Android 12 이상에서는 BLUETOOTH_CONNECT 권한이 없으면
         * 페어링된 장치의 MAC 주소를 접근조차 못함
         * → 권한 없으면 사용자에게 요청 */
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.BLUETOOTH_CONNECT},
                    1
            );
            return;
        }

        /* getRemoteDevice()
         * - 페어링된 블루투스 장치를 MAC 주소로 불러오는 함수
         * - 이 단계에서 실제 연결되는 건 아님 (객체만 생성됨) */
        BluetoothDevice device = btAdapter.getRemoteDevice(deviceAddress); // 객체 생성

        try {
            /* createRfcommSocketToServiceRecord()
             * - RFCOMM = 블루투스에서 UART 직렬 통신을 흉내내는 프로토콜
             * → 원래는 유선으로 통신하였지만 무선으로 하기 위해서 블루투스가 유선 통신 방식을 흉내냄
             * - SPP UUID로 표준 시리얼 통신 소켓 생성 */
            btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);

            /* HC-06은 전원을 넣고 바로 연결하면 실패하는 경우가 자주 있어서
             * 1초 정도 딜레이를 주면 안정적으로 연결됨 */
            try { Thread.sleep(1000); } catch (InterruptedException ignored) {}

            btSocket.connect(); // 블루투스 연결

        } catch (IOException e1) { // 기본 방식 실패 시 → 채널 1번을 강제로 지정해 연결하는 비표준 방법
            e1.printStackTrace();

            try {
                btSocket = (BluetoothSocket) device.getClass()
                        .getMethod("createRfcommSocket", int.class)
                        .invoke(device, 1);

                btSocket.connect();

            } catch (Exception e2) {
                // 두 번째 방법도 실패하면 연결 시도 종료
                e2.printStackTrace();
                textView.setText("연결 실패: " + e2.getMessage());
                return;
            }
        }

        try {
            /* 연결 성공 후 InputStream 생성
             * 이제부터 HC-06 → Android 방향 데이터 읽기 가능 */
            inputStream = btSocket.getInputStream();
        } catch (IOException e) {
            textView.setText("스트림 오류: " + e.getMessage());
            return;
        }

        /* 블루투스 데이터 읽기 스레드
         * - UI 스레드를 막지 않기 위해 별도의 스레드에서 실행
         * - 1바이트씩 들어오는 데이터를 줄 단위(\n)로 묶어서 출력 */
        new Thread(() -> {
            byte[] buffer = new byte[1024];
            int bytes;

            while (true) {
                try {
                    // 수신된 데이터의 길이를 bytes에 저장
                    bytes = inputStream.read(buffer);
                    String incoming = new String(buffer, 0, bytes);

                    // 1 byte씩 오는 데이터를 뒤에 이어붙이기
                    messageBuffer += incoming;

                    /* '\n'이 들어올 때마다 한 줄씩 완성된 메시지를 분리해서 출력 */
                    while (messageBuffer.contains("\n")) {
                        int index = messageBuffer.indexOf("\n");

                        // '\n' 이전까지만 한 줄로 추출
                        String fullLine = messageBuffer.substring(0, index);
                        // 남아 있는 나머지 문자열은 다시 버퍼에 저장
                        messageBuffer = messageBuffer.substring(index + 1);

                        // UI 스레드에서 TextView 업데이트
                        runOnUiThread(() -> textView.setText(fullLine));
                    }

                } catch (IOException e) {
                    // HC-06 연결 해제 또는 오류 발생 시 스레드 종료
                    break;
                }
            }
        }).start();
    }
}
