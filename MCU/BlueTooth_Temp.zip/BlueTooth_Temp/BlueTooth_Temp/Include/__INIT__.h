﻿#ifndef __INIT___H_
#define __INIT___H_

#define F_CPU 14745600
#define __PRINTF_USE_FLOAT__

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// LCD 모듈
#define LCD_PORT PORTC
#define LCD_DDR DDRC
#define LCD_RS PORTC4 // RS: 지금 보내는 값이 명령어인지 데이터인지 구분
#define LCD_EN PORTC5 // E: LCD가 데이터를 받아들이는 시점을 정함

void LCD_Enable(void);
void LCD_Send4Bit(uint8_t data);
void LCD_Command(uint8_t cmd);
void LCD_Data(uint8_t data);
void LCD_Init(void);
void LCD_String(char *str);
void LCD_SetCursor(uint8_t col, uint8_t row);
void LCD_Clear_all(void);
void LCD_ClearLine(uint8_t row);

// TEMP 모듈
#define TEMP_PORT PORTD
#define TEMP_DDR DDRD
#define Slave_Address 0x40
#define tempCommand 0xE3

void TEMP_Init(void);
void Set_START(void);
void Set_STOP(void);
void StartTransmission(uint8_t RW_bit);
void Write_DATA(uint8_t DATA);
uint8_t Read_DATA(int ACK);
float TEMP_ReadByte(void);

// USART
void USART_Init(void);
void USART_TX(unsigned char data);
char USART_RX(void);
void USART_SEND(char* str);
void USART_RECEIVE(char* buff, int size);
void USART_Flush(void);

#endif /* __INIT___H_ */