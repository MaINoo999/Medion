#include "Include/__INIT__.h"
#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
	
	LCD_Init();
	TEMP_Init();
	USART_Init();
	sei();
	
	float temperature = 0;
	int temp_int = 0;
	int temp_dec = 0;
	char buf[20];
	
    while (1) 
    {
		temperature = TEMP_ReadByte();
		temp_int = (int)temperature;
		temp_dec = (int)((temperature - temp_int) * 100);
		sprintf(buf, "Temp: %d.%02d\r\n", temp_int, abs(temp_dec));
		USART_SEND(buf);
    }
}

