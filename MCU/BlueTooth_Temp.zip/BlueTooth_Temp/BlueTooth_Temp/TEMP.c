﻿#include "Include/__INIT__.h"

void TEMP_Init(void) {
	//DDR 설정하지 않은 이유는 TWI 기능이 전용 하드웨어 핀을 사용하기 때문(회로와 직접 연결)
	// PORTD0 SCL, PORTD1 SDA
	TEMP_PORT |= (1<<PORTD0) | (1<<PORTD1); // 내부 풀업저항 1로 세트
	
	// 비트율 설정(TWBR + 프리스케일러)
	TWBR = 0x02;
	TWSR |= (1<<TWPS0); // 4분주
}

void Set_START(void) {
	// TWI 제어 레지스터 설정
	// - TWINT : 인터럽트 플래그 클리어 (새 동작 시작 신호)
	// - TWSTA : START 조건 전송 요청 (마스터 모드 진입)
	// - TWEN  : TWI 하드웨어 활성화
	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN);
	
	// TWI 하드웨어 기다리기(0으로 세트) & START 상태 태그
	while((((TWCR & (1<<TWINT)) == 0x00) || ((TWSR & 0xF8) != 0x08)));
}

void Set_STOP(void) {
	TWCR = (1<<TWINT) | (1<<TWSTO) | (1<<TWEN);
}

void StartTransmission(uint8_t RW_bit) {
	// SLA + W 또는 SLA + R
	TWDR = (Slave_Address << 1) + RW_bit; //RW_bit이 0이면 +0, 1이면 +1
	TWCR = (1<<TWINT) | (1<<TWEN);
	if (!RW_bit) {
		while (((TWCR & (1<<TWINT)) == 0x00) || ((TWSR & 0xF8) != 0x18));
		} else {
		while (((TWCR & (1<<TWINT)) == 0x00) || ((TWSR & 0xF8) != 0x40));
	}
}

void Write_DATA(uint8_t DATA) {
	// 데이터 쓰기
	TWDR = DATA; // TEMP : 온도 측정 명령어 0xE3
	TWCR = (1<<TWINT) | (1<<TWEN);
	while (((TWCR & (1<<TWINT)) == 0x00) || ((TWSR & 0xF8) != 0x28));
}

uint8_t Read_DATA(int ACK) {
	// 데이터 읽기
	if (ACK) {
		TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA);
		while (((TWCR & (1<<TWINT)) == 0x00) || (TWSR & 0xF8) != 0x50);
		} else {
		TWCR = (1<<TWINT) | (1<<TWEN);
		while (((TWCR & (1<<TWINT)) == 0x00) || (TWSR & 0xF8) != 0x58);
	}
	
	return TWDR;
}

float TEMP_ReadByte(void) {
	// 명령어 보내기
	Set_START();
	
	StartTransmission(0);
	
	Write_DATA(tempCommand);
	
	Set_STOP();
	
	// 데이터 읽기(온도)
	Set_START();
	
	StartTransmission(1);
	
	uint8_t msb = Read_DATA(1);
	uint8_t lsb = Read_DATA(0);
	
	Set_STOP();
	
	uint16_t raw_temp = ((uint16_t)msb << 8) | lsb;
	raw_temp &= 0xFFFC;
	
	char buffer[20];
	sprintf(buffer, "Sensor: %d", raw_temp);
	
	LCD_Clear_all();
	LCD_SetCursor(0, 0);
	LCD_String(buffer);
	
	float temperature = -46.85 + (175.72 * (raw_temp / 65536.0));
	
	int temp_int = (int)temperature;
	int temp_dec = (int)((temperature - temp_int) * 100);  // 소수 둘째 자리까지

	char buffer2[20];
	sprintf(buffer2, "Temp: %d.%02d", temp_int, abs(temp_dec)); // abs: 절댓값
	LCD_SetCursor(1, 0);
	LCD_String(buffer2);
	_delay_ms(1000);
	
	return temperature;
}