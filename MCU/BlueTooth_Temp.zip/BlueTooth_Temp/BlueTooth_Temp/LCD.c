﻿#include "Include/__INIT__.h"

// LCD가 데이터를 읽도록 E(Enable)에 펄스를 주는 함수
void LCD_Enable(void) {
	LCD_PORT |= (1<<LCD_EN); //LCD 사용
	_delay_ms(1);
	LCD_PORT &= ~(1<<LCD_EN); //LCD 사용 안 함
	_delay_ms(100);
}

// 4비트(하위 4비트)를 LCD 데이터핀으로 전송
void LCD_Send4Bit(uint8_t data) {
	LCD_PORT = (LCD_PORT & 0xF0) | (data & 0x0F); //하위 4비트만 반영
	LCD_Enable();
}

// LCD에 명령어를 보냄
void LCD_Command(uint8_t cmd) {
	LCD_PORT &= ~(1<<LCD_RS); //RS = 0(명령어)
	LCD_Send4Bit(cmd >> 4); //상위 4비트
	LCD_Send4Bit(cmd & 0x0F); //하위 4비트
}

// LCD에 실제 문자 데이터를 보냄(ASCII 코드)
void LCD_Data(uint8_t data) {
	LCD_PORT |= (1<<LCD_RS); // RS=1 (데이터)
	LCD_Send4Bit(data >> 4); // 상위 4비트
	LCD_Send4Bit(data & 0x0F); // 하위 4비트
}

// LCD 초기화
void LCD_Init(void) {
	LCD_DDR = 0xFF;  // PORTC 전부 출력
	_delay_ms(20);

	LCD_Command(0x02); // 4bit 모드 진입
	LCD_Command(0x28); // 4bit, 2라인, 5x7 폰트
	LCD_Command(0x0C); // 디스플레이 ON, 커서 OFF
	LCD_Command(0x06); // 자동 커서 이동
	LCD_Command(0x01); // 화면 클리어
	_delay_ms(2);
}

// 문자열을 LCD에 출력
void LCD_String(char *str) {
	while(*str) {
		LCD_Data(*str++);
	}
}

// LCD 커서 위치 설정
void LCD_SetCursor(uint8_t row, uint8_t col) {
	uint8_t pos[] = {0x00, 0x40}; // 1행=0x00, 2행=0x40
	LCD_Command(0x80 | (pos[row] + col));
}

void LCD_Clear_all(void) {
	LCD_Command(0x01);   // 화면 전체 클리어 (Display Clear)
	_delay_ms(2);        // 명령 처리 시간 (약 1.53ms 필요)
}

void LCD_ClearLine(uint8_t row) {
	uint8_t pos[] = {0x00, 0x40};
	LCD_SetCursor(row, 0);
	uint8_t col;
	for (col = 0; col < 16; col++) {
		LCD_Data(' ');
	} LCD_SetCursor(row, 0);
}